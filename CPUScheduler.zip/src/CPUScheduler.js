import React, { useState, useEffect, useRef } from "react";
import Chart from 'chart.js/auto';
import "bootstrap/dist/css/bootstrap.min.css";

const CPUScheduler = () => {
  const [tasks, setTasks] = useState([]);
  const [quantum, setQuantum] = useState(2);
  const [algorithmResults, setAlgorithmResults] = useState({});
  const [selectedAlgorithm, setSelectedAlgorithm] = useState(null);
  const chartRef = useRef(null);
  const [chartInstance, setChartInstance] = useState(null);

  const addTask = () => {
    setTasks([...tasks, { id: tasks.length + 1, arrival: 0, burst: 1, priority: 1 }]);
  };

  const updateTask = (index, field, value) => {
    const updatedTasks = [...tasks];
    updatedTasks[index][field] = Number(value);
    setTasks(updatedTasks);
  };

  // Scheduling Algorithms
  const fcfs = (originalTasks) => {
    const tasks = originalTasks.map(task => ({ ...task }));
    tasks.sort((a, b) => a.arrival - b.arrival);
    let currentTime = 0, schedule = [];
    
    tasks.forEach((task) => {
      const startTime = Math.max(currentTime, task.arrival);
      const finishTime = startTime + task.burst;
      schedule.push({ 
        id: task.id, 
        startTime, 
        finishTime,
        arrival: task.arrival,
        burst: task.burst,
        priority: task.priority
      });
      currentTime = finishTime;
    });

    const waitingTimes = tasks.map(task => {
      const scheduledTask = schedule.find(t => t.id === task.id);
      return scheduledTask.startTime - task.arrival;
    });

    const turnaroundTimes = tasks.map(task => {
      const scheduledTask = schedule.find(t => t.id === task.id);
      return scheduledTask.finishTime - task.arrival;
    });

    return {
      schedule,
      avgWait: waitingTimes.reduce((a, b) => a + b, 0) / tasks.length,
      avgTurnaround: turnaroundTimes.reduce((a, b) => a + b, 0) / tasks.length,
      executionSteps: schedule.map(step => ({
        task: step.id,
        start: step.startTime,
        finish: step.finishTime
      }))
    };
  };

  const roundRobin = (originalTasks, quantum) => {
    const tasks = originalTasks.map(task => ({ ...task, remaining: task.burst }));
    const queue = [...tasks];
    let time = 0;
    const schedule = [];
    const completionTimes = {};

    while (queue.length > 0) {
      const task = queue.shift();
      const executeTime = Math.min(quantum, task.remaining);
      
      schedule.push({
        id: task.id,
        startTime: time,
        finishTime: time + executeTime
      });

      time += executeTime;
      task.remaining -= executeTime;

      if (task.remaining > 0) {
        queue.push(task);
      } else {
        completionTimes[task.id] = time;
      }
    }

    const waitingTimes = originalTasks.map(task => {
      const turnaround = completionTimes[task.id] - task.arrival;
      return turnaround - task.burst;
    });

    return {
      schedule,
      avgWait: waitingTimes.reduce((a, b) => a + b, 0) / originalTasks.length,
      avgTurnaround: originalTasks.map(task => completionTimes[task.id] - task.arrival)
        .reduce((a, b) => a + b, 0) / originalTasks.length,
      executionSteps: schedule.map(step => ({
        task: step.id,
        start: step.startTime,
        finish: step.finishTime
      }))
    };
  };

  const spn = (originalTasks) => {
    const tasks = [...originalTasks];
    tasks.sort((a, b) => a.burst - b.burst);
    const result = fcfs(tasks);
    return {
      ...result,
      executionSteps: result.schedule.map(step => ({
        task: step.id,
        start: step.startTime,
        finish: step.finishTime
      }))
    };
  };

  const srtn = (originalTasks) => {
    const tasks = originalTasks.map(task => ({ ...task, remaining: task.burst }));
    let time = 0;
    const schedule = [];
    const completionTimes = {};

    while (true) {
      let eligibleTasks = tasks.filter(t => t.remaining > 0 && t.arrival <= time);
      if (eligibleTasks.length === 0) {
        if (tasks.some(t => t.remaining > 0)) time++;
        else break;
        continue;
      }

      const shortest = eligibleTasks.reduce((prev, curr) => 
        curr.remaining < prev.remaining ? curr : prev
      );

      schedule.push({ 
        id: shortest.id, 
        startTime: time, 
        finishTime: time + 1 
      });
      time++;
      shortest.remaining--;

      if (shortest.remaining === 0) {
        completionTimes[shortest.id] = time;
      }
    }

    const waitingTimes = originalTasks.map(task => {
      const turnaround = completionTimes[task.id] - task.arrival;
      return turnaround - task.burst;
    });

    return {
      schedule,
      avgWait: waitingTimes.reduce((a, b) => a + b, 0) / originalTasks.length,
      avgTurnaround: originalTasks.map(task => completionTimes[task.id] - task.arrival)
        .reduce((a, b) => a + b, 0) / originalTasks.length,
      executionSteps: schedule.map(step => ({
        task: step.id,
        start: step.startTime,
        finish: step.finishTime
      }))
    };
  };

  const priorityScheduling = (originalTasks) => {
    const tasks = [...originalTasks];
    tasks.sort((a, b) => a.priority - b.priority);
    const result = fcfs(tasks);
    return {
      ...result,
      executionSteps: result.schedule.map(step => ({
        task: step.id,
        start: step.startTime,
        finish: step.finishTime
      }))
    };
  };

  const getBestAlgorithms = () => {
    if (Object.keys(algorithmResults).length === 0) return {};
    
    const algorithms = Object.entries(algorithmResults);
    const validResults = algorithms.filter(([_, result]) => 
      !isNaN(result.avgWait) && !isNaN(result.avgTurnaround)
    );
    
    const minWait = Math.min(...validResults.map(([_, result]) => result.avgWait));
    const minTurnaround = Math.min(...validResults.map(([_, result]) => result.avgTurnaround));

    return {
      bestWait: validResults.filter(([_, result]) => result.avgWait === minWait).map(([name]) => name),
      bestTurnaround: validResults.filter(([_, result]) => result.avgTurnaround === minTurnaround).map(([name]) => name)
    };
  };

  const runAllAlgorithms = () => {
    const algorithms = [
      { name: "FCFS", func: () => fcfs(tasks) },
      { name: "Round Robin", func: () => roundRobin(tasks, quantum) },
      { name: "SPN", func: () => spn(tasks) },
      { name: "SRTN", func: () => srtn(tasks) },
      { name: "Priority", func: () => priorityScheduling(tasks) }
    ];

    const results = {};
    algorithms.forEach(algo => {
      try {
        results[algo.name] = algo.func();
      } catch (error) {
        console.error(`Error running ${algo.name}:`, error);
        results[algo.name] = { 
          avgWait: NaN, 
          avgTurnaround: NaN,
          executionSteps: []
        };
      }
    });

    setAlgorithmResults(results);
    setSelectedAlgorithm(null);
  };

  useEffect(() => {
    if (chartInstance) chartInstance.destroy();
    if (Object.keys(algorithmResults).length === 0) return;

    const ctx = chartRef.current.getContext('2d');
    const labels = Object.keys(algorithmResults);
    const avgWaitData = labels.map(algo => algorithmResults[algo].avgWait);
    const avgTurnaroundData = labels.map(algo => algorithmResults[algo].avgTurnaround);

    const newChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Average Waiting Time',
            data: avgWaitData,
            backgroundColor: 'rgba(255, 99, 132, 0.5)',
          },
          {
            label: 'Average Turnaround Time',
            data: avgTurnaroundData,
            backgroundColor: 'rgba(54, 162, 235, 0.5)',
          }
        ]
      },
      options: {
        scales: {
          y: { beginAtZero: true }
        }
      }
    });

    setChartInstance(newChart);
  }, [algorithmResults]);

  return (
    <div className="container mt-4">
      <h2 className="text-center">CPU Scheduling Simulator</h2>

      <button className="btn btn-primary mt-3" onClick={addTask}>Add Task</button>

      <table className="table table-bordered mt-3">
        <thead>
          <tr>
            <th>ID</th>
            <th>Arrival Time</th>
            <th>Burst Time</th>
            <th>Priority</th>
          </tr>
        </thead>
        <tbody>
          {tasks.map((task, index) => (
            <tr key={task.id}>
              <td>{task.id}</td>
              <td>
                <input type="number" value={task.arrival} 
                  onChange={(e) => updateTask(index, "arrival", e.target.value)} />
              </td>
              <td>
                <input type="number" value={task.burst} 
                  onChange={(e) => updateTask(index, "burst", e.target.value)} />
              </td>
              <td>
                <input type="number" value={task.priority} 
                  onChange={(e) => updateTask(index, "priority", e.target.value)} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mt-3">
        <label>Round Robin Time Quantum:</label>
        <input type="number" value={quantum} 
          onChange={(e) => setQuantum(Number(e.target.value))} 
          className="form-control mt-2" />
      </div>

      <button className="btn btn-success mt-3" onClick={runAllAlgorithms}>
        Run All Algorithms
      </button>

      {Object.keys(algorithmResults).length > 0 && (
        <div className="mt-4">
          <h4>Performance Comparison</h4>
          <canvas ref={chartRef}></canvas>
          
          <div className="mt-4 alert alert-info">
            <h5>🥇 Best Performing Algorithms:</h5>
            <div className="row">
              <div className="col-md-6">
                <strong>Best Waiting Time:</strong><br/>
                {getBestAlgorithms().bestWait.map(name => (
                  <span key={name} className="badge bg-success me-2">
                    {name} ({algorithmResults[name].avgWait.toFixed(2)})
                  </span>
                ))}
              </div>
              <div className="col-md-6">
                <strong>Best Turnaround Time:</strong><br/>
                {getBestAlgorithms().bestTurnaround.map(name => (
                  <span key={name} className="badge bg-success me-2">
                    {name} ({algorithmResults[name].avgTurnaround.toFixed(2)})
                  </span>
                ))}
              </div>
            </div>
          </div>

          <h5 className="mt-4">Detailed Results</h5>
          <table className="table table-striped">
            <thead>
              <tr>
                <th>Algorithm</th>
                <th>Avg Waiting Time</th>
                <th>Avg Turnaround Time</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(algorithmResults).map(([name, result]) => {
                const best = getBestAlgorithms();
                const isBestWait = best.bestWait.includes(name);
                const isBestTurnaround = best.bestTurnaround.includes(name);
                
                return (
                  <tr key={name} 
                      onClick={() => setSelectedAlgorithm(selectedAlgorithm === name ? null : name)}
                      style={{ cursor: 'pointer' }}
                      className={isBestWait || isBestTurnaround ? 'table-success' : ''}>
                    <td>{name}</td>
                    <td>
                      {result.avgWait.toFixed(2)}
                      {isBestWait && <span className="ms-2">🥇</span>}
                    </td>
                    <td>
                      {result.avgTurnaround.toFixed(2)}
                      {isBestTurnaround && <span className="ms-2">🥇</span>}
                    </td>
                    <td>
                      <button className="btn btn-sm btn-info">
                        {selectedAlgorithm === name ? 'Hide' : 'Show'} Timeline
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {selectedAlgorithm && algorithmResults[selectedAlgorithm] && (
            <div className="mt-4">
              <h5>{selectedAlgorithm} Execution Timeline</h5>
              <table className="table table-bordered">
                <thead>
                  <tr>
                    <th>Task</th>
                    <th>Start Time</th>
                    <th>Finish Time</th>
                    <th>Arrival Time</th>
                    <th>Burst Time</th>
                    <th>Priority</th>
                  </tr>
                </thead>
                <tbody>
                  {algorithmResults[selectedAlgorithm].executionSteps.map((step, index) => {
                    const originalTask = tasks.find(t => t.id === step.task);
                    return (
                      <tr key={index}>
                        <td>Task {step.task}</td>
                        <td>{step.start}</td>
                        <td>{step.finish}</td>
                        <td>{originalTask?.arrival}</td>
                        <td>{originalTask?.burst}</td>
                        <td>{originalTask?.priority}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default CPUScheduler;
import React from "react";
import CPUScheduler from "./CPUScheduler";

function App() {
  return (
    <div className="App">
      <CPUScheduler />
    </div>
  );
}

export default App;
